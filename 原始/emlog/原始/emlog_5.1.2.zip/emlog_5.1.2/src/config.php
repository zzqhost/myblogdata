<?php
header("location: ./install.php");exit;
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','root');
//database password
define('DB_PASSWD','');
//database name
define('DB_NAME','emlog');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','VWq5RC2k1T*^1gdvJ1*VFn50e1LSgc#M4c8ba17bcb8bf97039c28fe8d792d7c5');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_gSozFLFifPYsLA2MZC4lLv3d23jvbo7Q');
