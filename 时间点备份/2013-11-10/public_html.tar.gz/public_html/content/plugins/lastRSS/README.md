emlog Rss订阅插件
====================

订阅你喜欢的网站的feed，然后显示在博客前台，有可能把访客带到别的站，但是，不影响SEO，因为，前台都是通过ajax请求的。

[插件主页](http://xiaosong.org/share/the-official-releas-of-rss-subscribe-plugin)