<?php
	$lastRSS_cache_time = 3600;
	$lastRSS_item_num = 5;
	$lastRSS_is_urlshort = 0;
  $lastRSS_urlshort_domain = 't.cn';
	$lastRSS_is_blank = 1;
?>