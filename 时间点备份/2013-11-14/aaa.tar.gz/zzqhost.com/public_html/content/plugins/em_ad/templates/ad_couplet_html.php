<div id="left_couplet">
	<div class="close_button" id="left_close">
		<a href="javascript:;" >关闭</a>
	</div>		
	<div><?php echo $ad_html ?></div>
</div>
<div id="right_couplet">
	<div class="close_button" id="right_close">
		<a href="javascript:;" >关闭</a>
	</div>	
	<div><?php echo $ad_html ?></div>
</div>