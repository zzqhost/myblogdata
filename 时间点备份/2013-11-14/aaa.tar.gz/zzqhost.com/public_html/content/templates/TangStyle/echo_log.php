<?php 
/*
* 阅读日志页面
*/
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div id="main">
<div id="article">
	<h1><?php topflg($top); ?><?php echo $log_title; ?></h1>
	<p class="info">作者：<?php blog_author($author); ?> 发布于：<?php echo gmdate('Y-n-j G:i l', $date); ?> 
	<?php blog_sort($logid); ?> <?php editflg($logid,$author); ?>
	</p>
	<div class="text"><?php echo $log_content; ?></div>
		<div class="text_add">
			<div class="copy"><p style="color:#F00;">本文出自 <?php echo $blogname; ?>，转载时请注明出处及相应链接。</p></div>
		</div>
	<div class="meta"><i class="iconfont">&#48;</i><?php blog_tag($logid); ?></div>
	<?php doAction('log_related', $logData); ?>
</div>
<div class="post_link">
	<?php neighbor_log($neighborLog); ?>
</div>
<div id="comments">
	<?php blog_comments($comments); ?>
	<?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	<div style="clear:both;"></div>
</div>
</div>
<?php
 include View::getView('side');
 include View::getView('footer');
?>