<?php
//mysql database address
define('DB_HOST','localhost');
//mysql database user
define('DB_USER','avvkotzb_zzq');
//database password
define('DB_PASSWD','BtNwdg3f');
//database name
define('DB_NAME','avvkotzb_emlog');
//database prefix
define('DB_PREFIX','emlog_');
//auth key
define('AUTH_KEY','wE1S9PNWqm6#l$$dOvnn%Uh8o$@6kfFX06d41edcaa35d413589b9b6b6d878b4f');
//cookie name
define('AUTH_COOKIE_NAME','EM_AUTHCOOKIE_towItHjo7pztoGorIsMWxs77TtCHnwz0');
