<?php defined('EMLOG_ROOT') or die('本页面禁止直接访问!'); ?>
<style>
	#em_ad {
		color: #555555;
	}
	#em_ad .hidden {
		display: none;
	}
	#em_ad .warning {
		border:1px solid orange;
		color: orange;
		padding: 10px;
		margin: 10px auto;
		text-align: center;
	}

</style>