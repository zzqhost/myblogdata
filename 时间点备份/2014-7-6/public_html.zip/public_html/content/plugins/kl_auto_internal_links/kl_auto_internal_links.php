<?php
/*
Plugin Name: 自动内链
Version: 1.2
Plugin URL: http://kller.cn/?post=126
Description: 自动将文章中含有已存在的标签和分类自动替换成带链接的标签。
ForEmlog: 理论上大于4.0.0版本的博客都能用
Author: KLLER
Author Email: kller@foxmail.com
Author URL: http://kller.cn
*/
!defined('EMLOG_ROOT') && exit('access deined!');
define('KL_AUTO_INTERNAL_LINKS_ROOT', EMLOG_ROOT.'/content/plugins/kl_auto_internal_links');

function kl_auto_internal_links()
{
	echo '<div class="sidebarsubmenu" id="kl_auto_internal_links"><a href="./plugin.php?plugin=kl_auto_internal_links">自动内链</a></div>';
}
addAction('adm_sidebar_ext', 'kl_auto_internal_links');

function kl_auto_internal_links_to_backup(){
	global $tables;
	array_push($tables, 'kl_auto_internal_links');
}
addAction('data_prebakup', 'kl_auto_internal_links_to_backup');

function kl_auto_internal_links_zouni($blogid)
{
	$kl_auto_internal_links_info = unserialize(Option::get('kl_auto_internal_links_info'));
	if(!$kl_auto_internal_links_info['onsave']) return;
	global $logData, $Log_Model;
	if($logData['content'] != ''){
		$logData['content'] = kl_auto_internal_links_do($logData['content']);
		$Log_Model->updateLog($logData, $blogid);
	}
}
addAction('save_log', 'kl_auto_internal_links_zouni');

function kl_auto_internal_links_css()
{
	$kl_auto_internal_links_info = unserialize(Option::get('kl_auto_internal_links_info'));
	if($kl_auto_internal_links_info['css'] != '') echo base64_decode($kl_auto_internal_links_info['css']);
}
addAction('index_head', 'kl_auto_internal_links_css');

function kl_auto_internal_links_do($content)
{
	$kl_auto_internal_links_info = unserialize(Option::get('kl_auto_internal_links_info'));
	if($kl_auto_internal_links_info['how'] == 2){
		return kl_auto_internal_links_restore($content);
	}elseif($kl_auto_internal_links_info['how'] == 1){
		return kl_auto_internal_links_restore($content, false);
	}else{
		$content = kl_auto_internal_links_restore($content);
	}
	global $CACHE;
	$tag_arr = $sort_arr = $custom_arr = $word_arr = array();
	if($kl_auto_internal_links_info['kl_sort']){
		$sort_cache = $CACHE->readCache('sort');
		foreach($sort_cache as $sort) $sort_arr[$sort['sortname']] = array('type'=>'sort', 'url'=>kl_auto_internal_links_url_convent('sort', $sort['sid']), 'target'=>$kl_auto_internal_links_info['kl_sort_target'], 'nofollow'=>$kl_auto_internal_links_info['kl_sort_nofollow'], 'title'=>$kl_auto_internal_links_info['kl_sort_title'], 'title_text'=>$kl_auto_internal_links_info['kl_sort_title_text'], 'class'=>'kl_auto_internal_links_sort', 'weight'=>$kl_auto_internal_links_info['kl_sort_weight']);
	}
	if($kl_auto_internal_links_info['kl_tag']){
		$tag_cache = $CACHE->readCache('tags');
		foreach($tag_cache as $tag)	$tag_arr[$tag['tagname']] = array('type'=>'tag', 'url'=>kl_auto_internal_links_url_convent('tag', $tag['tagname']), 'target'=>$kl_auto_internal_links_info['kl_tag_target'], 'nofollow'=>$kl_auto_internal_links_info['kl_tag_nofollow'], 'title'=>$kl_auto_internal_links_info['kl_tag_title'], 'title_text'=>$kl_auto_internal_links_info['kl_tag_title_text'], 'class'=>'kl_auto_internal_links_tag', 'weight'=>$kl_auto_internal_links_info['kl_tag_weight']);
	}
	if($kl_auto_internal_links_info['kl_custom']){
		$custom_cache = kl_auto_internal_links_get_custom();
		foreach($custom_cache as $custom) $custom_arr[$custom['word']] = array('type'=>'custom', 'url'=>$custom['url'], 'target'=>$custom['target'], 'nofollow'=>$custom['nofollow'], 'title'=>$custom['title'], 'title_text'=>$custom['title_text'], 'class'=>$custom['class'], 'weight'=>$custom['weight']);
	}
	if($kl_auto_internal_links_info['priority'] == 1){
		$word_arr = array_merge($tag_arr, $custom_arr, $sort_arr);
	}elseif($kl_auto_internal_links_info['priority'] == 2){
		$word_arr = array_merge($custom_arr, $sort_arr, $tag_arr);
	}elseif($kl_auto_internal_links_info['priority'] == 3){
		$word_arr = array_merge($sort_arr, $custom_arr, $tag_arr);
	}elseif($kl_auto_internal_links_info['priority'] == 4){
		$word_arr = array_merge($tag_arr, $sort_arr, $custom_arr);
	}elseif($kl_auto_internal_links_info['priority'] == 5){
		$word_arr = array_merge($sort_arr, $tag_arr, $custom_arr);
	}else{
		$word_arr = array_merge($custom_arr, $tag_arr, $sort_arr);
	}
	$new_word_arr = array();
	$i = 0;
	foreach($word_arr as $wak => $wav){
		$wav['word'] = $wak;
		$wav['mark'] = $i;
		array_push($new_word_arr, $wav);
		$i++;
	}
	$word_arr = $new_word_arr;
	usort($word_arr, 'kl_auto_internal_links_cmp_word');
	$content = stripslashes($content);
	preg_match_all('%<a [^>]+?>.*?<\/a>%s', $content, $dataArr, PREG_PATTERN_ORDER);
	$kl_pattern = array();
	foreach($dataArr[0] as $k => $v)
	{
		$content = str_replace($v, '<||kl'.$k.'||>', $content);
		array_push($kl_pattern, '/<\|\|kl'.$k.'\|\|>/');
	}
	$special_chars = '('.implode(')|(', get_html_translation_table(HTML_ENTITIES)).')';
	$content = preg_split("/(<[^>]+?>)|{$special_chars}/si", $content, -1, PREG_SPLIT_NO_EMPTY| PREG_SPLIT_DELIM_CAPTURE);
	$stat = array();
	$the_stat = 0;
	for($i = 0; $i < count($content); $i++)
	{
		if(preg_match("/(<[^>]+?>)/si",$content[$i])) continue;
		$word_arr_o = $word_arr;
		foreach($word_arr_o as $word_key=>$word) if(strpos($content[$i], $word['word']) === false) unset($word_arr_o[$word_key]);
		if(empty($word_arr_o)) continue;
		foreach($word_arr_o as $word_key => $word)
		{
			foreach($word_arr_o as $word_bak)
			{
				if($word_bak['word'] == $word['word']) continue;
				if(strpos($word_bak['word'], $word['word']) !== false) unset($word_arr_o[$word_key]);
			}
		}
		foreach($word_arr_o as $word) $content[$i] = preg_replace("/{$word['word']}/e", 'kl_auto_internal_links_replace($stat, $the_stat, $word)', $content[$i]);
	}
	$content = implode($content);
	foreach($stat as $mark=>$count){
		if(intval($kl_auto_internal_links_info['each_count']) != 0 && $count > $kl_auto_internal_links_info['each_count']){
			$data = kl_auto_internal_links_reduce($content, $kl_auto_internal_links_info['each_count'], $mark);
			$content = $data['content'];
			$the_stat -= $data['count'];
		}
	}
	if(intval($kl_auto_internal_links_info['all_count']) != 0 && $the_stat > $kl_auto_internal_links_info['all_count']){
		$data = kl_auto_internal_links_reduce($content, $kl_auto_internal_links_info['all_count']);
		$content = $data['content'];
	}

	array_push($kl_pattern, '/<a id=\"kl_auto_internal_links_[0-9]+_[0-9]+_[0-9]+\"/');
	array_push($dataArr[0], '<a');
	$content = preg_replace($kl_pattern, $dataArr[0], $content);
	return addslashes($content);
}

function kl_auto_internal_links_url_convent($type, $argu){
	if($type == 'tag'){
		$active_plugins = Option::get('active_plugins');
		if(in_array('em_static/em_static.php', $active_plugins) && class_exists('EMStatic') && defined('EM_STATIC_TAG_CACHE_FILE') && is_file(EM_STATIC_TAG_CACHE_FILE)){
			$em_tag_cache = include EM_STATIC_TAG_CACHE_FILE;
			$EMStatic = EMStatic::get_instance();
			return $EMStatic->page_link_replace(Url::tag($em_tag_cache[$argu]));
		}else{
			return Url::tag($argu);
		}
	}
	if($type == 'sort'){
		$active_plugins = Option::get('active_plugins');
		if(in_array('em_static/em_static.php', $active_plugins) && class_exists('EMStatic')){
			$EMStatic = EMStatic::get_instance();
			return $EMStatic->page_link_replace(Url::sort($argu));
		}else{
			return Url::sort($argu);
		}
	}
}

function kl_auto_internal_links_restore($content, $sure=true)
{
	$content = stripslashes($content);
	$pattern = "%<span class=\"kl_auto_internal_links_(sort|tag|custom_0|custom_1)\">.*?</span>%s";
	preg_match_all($pattern, $content, $data_arr, PREG_PATTERN_ORDER);
	if(!empty($data_arr[0]) && $sure){
		$data_arr[1] = array_map('strip_tags', $data_arr[0]);
		$content = str_replace($data_arr[0], $data_arr[1], $content);
	}
	return addslashes($content);
}

function kl_auto_internal_links_reduce($content, $the_count, $mark=false)
{
	$pattern = $mark === false ? "%<span class=\"kl_auto_internal_links_(sort|tag|custom_0|custom_1)\"><a id=\"kl_auto_internal_links_[0-9]+_([0-9]+)_[0-9]+\"[^>]*?>(.*?)</a></span>%s" : "%<span class=\"kl_auto_internal_links_(sort|tag|custom_0|custom_1)\"><a id=\"kl_auto_internal_links_{$mark}_[0-9]+_[0-9]+\"[^>]*?>(.*?)</a></span>%s";
	preg_match_all($pattern, $content, $data_arr, PREG_PATTERN_ORDER);
	if($mark === false){
		$data_arr[0] = kl_auto_internal_links_reduce_sort($data_arr);
	}else{
		shuffle($data_arr[0]);
	}
	$new_data_arr = array();
	$count = count($data_arr[0]) - $the_count;
	$new_data_arr[0] = array_slice($data_arr[0], 0, $count);
	$new_data_arr[1] = array_map('strip_tags', $new_data_arr[0]);
	$content = str_replace($new_data_arr[0], $new_data_arr[1], $content);
	return array('content'=>$content, 'count'=>$count);
}

function kl_auto_internal_links_reduce_sort($data_arr)
{
	$new_data_arr = $new_data_arr_b = array();
	foreach($data_arr[0] as $k=>$v) $new_data_arr[$data_arr[2][$k]][] = $v;
	uksort($new_data_arr, 'kl_auto_internal_links_cmp_weight');
	foreach($new_data_arr as $v){
		shuffle($v);
		$new_data_arr_b = array_merge($new_data_arr_b, $v);
	}
	return $new_data_arr_b;
}

function kl_auto_internal_links_cmp_weight($a, $b)
{
	$c = 0;
	if($a == $b) return $c;
	$c = $a < $b ? -1 : 1;
	return $c;
}

function kl_auto_internal_links_replace(&$stat, &$the_stat, $word)
{
	$stat[$word['mark']] = isset($stat[$word['mark']]) ? $stat[$word['mark']] + 1 : 1;
	$the_stat += 1;
	$target_str = $word['target'] ? ' target="_blank"' : '';
	$nofollow_str = $word['nofollow'] ? ' rel="nofollow"' : '';
	$title_str = $word['title'] ? " title=\"{$word['title_text']}\"" : '';
	$title_str = str_replace("{{$word['type']}}", $word['word'], $title_str);
	return "<span class=\"{$word['class']}\"><a id=\"kl_auto_internal_links_{$word['mark']}_{$word['weight']}_{$the_stat}\" href=\"{$word['url']}\"{$title_str}{$target_str}{$nofollow_str}>{$word['word']}</a></span>";
}

function kl_auto_internal_links_cmp_word($a, $b)
{
	$c = 0;
	if(strlen($a['word']) == strlen($b['word'])) return $c;
	$c = strlen($a['word']) < strlen($b['word']) ? -1 : 1;
	return $c;
}

function kl_auto_internal_links_showjsmessage($message)
{
	echo '<script type="text/javascript">kl_auto_internal_links_showjsmessage(\''.addslashes($message).' \');</script>'."\r\n";
	flush();
	ob_flush();
}

function kl_auto_internal_links_batch_do($condition, $ajax=false)
{
	$DB = Mysql::getInstance();
	$query = $DB->query('select * from '.DB_PREFIX."blog where 1 {$condition} order by gid");
	$n = 1;
	if($DB->num_rows($query) == 0){
		$message = "<span style=\"color:red\">没有找到相关的文章或页面。</span>";
		if($ajax){
			echo $message;
		}else{
			kl_auto_internal_links_showjsmessage($message);
		}
		return;
	}
	while($row = $DB->fetch_array($query)){
		$content = kl_auto_internal_links_do(addslashes($row['content']));
		$DB->query('update '.DB_PREFIX."blog set content='{$content}' where gid={$row['gid']}");
		$type = $row['type'] == 'blog' ? '文章' : '页面';
		$color = $row['type'] == 'blog' ? '#ff66cc' : '#339933';
		$kl_auto_internal_links_info = unserialize(Option::get('kl_auto_internal_links_info'));
		$option = $kl_auto_internal_links_info['how'] == 2 ? '清除' : '生成';
		if($ajax){
			echo "<span style=\"color:{$color}\">ID为{$row['gid']}的{$type}内链{$option}成功。</span>";
			return;
		}
		$message = "<span style=\"color:{$color}\">{$n}、ID为{$row['gid']}的<strong>{$type}</strong> {$row['title']} <strong>==></strong> 内链{$option}完成！</span>";
		kl_auto_internal_links_showjsmessage($message);
		$n++;
	}
}

function kl_auto_internal_links_ajax($ajax=false)
{
	if(!isset($_POST['kl_auto_internal_links_gid'])) return;
	$gid = intval($_POST['kl_auto_internal_links_gid']);
	if($gid == 0) return;
	$condition = " and gid={$gid}";
	kl_auto_internal_links_batch_do($condition, $ajax);
}

function kl_auto_internal_links_get_custom()
{
	$custom_arr = array();
	$cache_file = KL_AUTO_INTERNAL_LINKS_ROOT.'/cache/custom.php';
	if(file_exists($cache_file)){
		$custom_arr = include $cache_file;
		if(is_array($custom_arr)) return $custom_arr;
	}
	return kl_auto_internal_links_update_custom();
}

function kl_auto_internal_links_update_custom()
{
	$cache_file = KL_AUTO_INTERNAL_LINKS_ROOT.'/cache/custom.php';
	$DB = Mysql::getInstance();
	$query = $DB->query('select * from '.DB_PREFIX.'kl_auto_internal_links order by id');
	$custom_arr = array();
	$class_option_arr = array('kl_auto_internal_links_custom_0', 'kl_auto_internal_links_custom_1');
	while($row = $DB->fetch_array($query)){
		$row['class'] = $class_option_arr[$row['class']];
		array_push($custom_arr, $row);
	}
	@file_put_contents($cache_file, "<?php if(!defined('EMLOG_ROOT')) {exit('error!');}\nreturn ".var_export($custom_arr, true).';');
	return $custom_arr;
}

if(!function_exists('emDirect')){
	function emDirect($directUrl) {
		header("Location: $directUrl");
		exit;
	}
}