<?php
/**
 * kl_auto_backup_and_mail_test_do.php
 * design by KLLER
 */
require_once('../../../init.php');
!(ISLOGIN === true && ROLE == 'admin') && exit('access deined!');
kl_auto_internal_links_ajax(true);