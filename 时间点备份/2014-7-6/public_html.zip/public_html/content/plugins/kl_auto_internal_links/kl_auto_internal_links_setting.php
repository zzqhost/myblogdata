<?php
/**
 * 自动内链插件
 * design by KLLER
 */

!defined('EMLOG_ROOT') && exit('access deined!');

function plugin_setting_view()
{
	$kl_auto_internal_links_info = unserialize(Option::get('kl_auto_internal_links_info'));
	$warning_msg = is_writable('../content/plugins/kl_auto_internal_links/cache') ? '' : '<span class="error">kl_auto_internal_links/cache文件夹可能不可写，如果已经是可写状态，请忽略此信息。</span>';
	$do_option_arr = array('所有文章和页面', '所有文章', '所有页面');
	$do_option_str = '';
	foreach($do_option_arr as $value=>$do){
		$selected = isset($_POST['do']) && $value == intval($_POST['do']) ? ' selected' : '';
		$do_option_str .= "<option value=\"{$value}\"{$selected}>{$do}</option>";
	}
	$kl_auto_internal_links_gid = isset($_POST['kl_auto_internal_links_gid']) ? intval($_POST['kl_auto_internal_links_gid']) : '';
	if($kl_auto_internal_links_gid == 0) $kl_auto_internal_links_gid = '';
?>
<script type="text/javascript">
jQuery.fn.onlyPressNum = function(){$(this).css('ime-mode','disabled');$(this).css('-moz-user-select','none');$(this).bind('keydown',function(event){var k=event.keyCode;if(!((k==13)||(k==9)||(k==35)||(k == 36)||(k==8)||(k==46)||(k>=48&&k<=57)||(k>=96&&k<=105)||(k>=37&&k<=40))){event.preventDefault();}})}
jQuery(function($){
	$('#each_count, #all_count, #kl_auto_internal_links_gid, #kl_weight, #kl_sort_weight, #kl_tag_weight').onlyPressNum();
	$("#kl_auto_internal_links").addClass('sidebarsubmenu1');
	$('#do_btn').click(function(){var gid=parseInt($('#kl_auto_internal_links_gid').val());if(isNaN(gid) || gid==0){alert('ID必须是大于0的整数！');return false;};$('#kl_auto_internal_links_msg').html('操作中..');$.post('../content/plugins/kl_auto_internal_links/kl_auto_internal_links_ajax.php',{sid:Math.random(), 'kl_auto_internal_links_gid':$('#kl_auto_internal_links_gid').val()},function(result){if($.trim(result)!=''){$('#kl_auto_internal_links_msg').html(result);}else{$('#kl_auto_internal_links_msg').html('操作失败！');}});})
});
setTimeout(hideActived,2600);
function kl_auto_internal_links_showjsmessage(message){$('#notice').html($('#notice').html() + message + '<br />').scrollTop(100000);}
</script>
<style type="text/css">
.table_b { float:left;border-collapse: collapse;border-style: none; border:1px solid #ccc; width:100%;}
.table_b td { border:1px solid #e0e0e0; padding:2px 5px; line-height:22px; }
.error {margin:0px 20px;}
</style>
<div class=containertitle><b>自动内链</b><span style="font-size:12px;color:#999999;">（版本：<?php echo $kl_auto_internal_links_info['version']; ?>）</span><?php echo $warning_msg;?></div>
<div class=line></div>
<?php
	if(isset($_GET['act']) && trim($_GET['act']) == 'do'){
		if(isset($_POST['do'])){
			$do = intval($_POST['do']);
			$condition = '';
			if($do == 1) $condition .= " and `type`='blog'";
			if($do == 2) $condition .= " and `type`='page'";
			@set_time_limit(5000);
		}
?>
<div class="containertitle2">
<a class="navi1" href="?plugin=kl_auto_internal_links">基本设置</a>
<a class="navi4" href="?plugin=kl_auto_internal_links&act=custom">自定义关键词</a>
<a class="navi3" href="?plugin=kl_auto_internal_links&act=do">手动操作</a>
</div>
<div style="margin:5px 0px;">
	<form id="form2" name="form2" method="post" action="plugin.php?plugin=kl_auto_internal_links&act=do">
		<table width="500" border="0" cellspacing="1" cellpadding="0" class="table_b">
			<tr>
				<td colspan="4" height="30"><div style="color:red;"><strong>相关操作（此页面的操作依赖基本设置页面中设定的参数）：</strong></div></td>
			</tr>
			<tr>
				<td width="135" height="30"><span style="width:300px;">单篇文章或页面:</span></td>
				<td width="165"><input name="kl_auto_internal_links_gid" type="text" id="kl_auto_internal_links_gid" style="width:115px;" value="<?php echo $kl_auto_internal_links_gid; ?>" /></td>
				<td width="205">*这里填写相应文章或页面ID</td>
				<td><input id="do_btn" type="button" value="执行操作" /><div id="kl_auto_internal_links_msg" style="display:inline;"></div></td>
			</tr>
			<tr>
				<td height="30"><span style="width:200px;">批量:</span></td>
				<td><select name="do"><?php echo $do_option_str; ?></select></td>
				<td>* 选择相应的范围</td>
				<td><input name="input" type="submit" value="执行操作" /></td>
			</tr>
			<tr>
				<td colspan="4">批量操作进度：</td>
			</tr>
			<tr>
				<td height="230" colspan="4"><div id="notice" style="height:214px; padding:5px; border:1px dashed #ccc; overflow:auto;"></div></td>
			</tr>
		</table>
	</form>
</div>
<?php
		if(isset($_POST['do'])) kl_auto_internal_links_batch_do($condition);
		exit;
	}elseif(isset($_GET['act']) && trim($_GET['act']) == 'custom'){
		$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
		$keyword = isset($_GET['keyword']) ? addslashes(trim($_GET['keyword'])) : '';
		$keyword_url = empty($keyword) ? '' : '&keyword='.$keyword;
		$DB = mysql::getInstance();
		if(isset($_GET['do']) && trim($_GET['do']) == 'add'){
			$kl_id = isset($_POST['kl_id']) ? intval($_POST['kl_id']) : 0;
			$kl_word = isset($_POST['kl_word']) ? addslashes(trim($_POST['kl_word'])) : '';
			$kl_url = isset($_POST['kl_url']) ? addslashes(trim($_POST['kl_url'])) : '';
			$kl_target = isset($_POST['kl_target']) ? intval($_POST['kl_target']) : 0;
			$kl_nofollow = isset($_POST['kl_nofollow']) ? intval($_POST['kl_nofollow']) : 0;
			$kl_title = isset($_POST['kl_title']) ? intval($_POST['kl_title']) : 0;
			$kl_weight = isset($_POST['kl_weight']) ? intval($_POST['kl_weight']) : 10;
			if($kl_weight > 99999) $kl_weight = 99999;
			$kl_title_text = isset($_POST['kl_title_text']) ? addslashes(trim($_POST['kl_title_text'])) : '';
			$kl_class = isset($_POST['kl_class']) ? intval($_POST['kl_class']) : 0;
			if($kl_word == '' || $kl_url == '')	emDirect("./plugin.php?plugin=kl_auto_internal_links&act=custom&page={$page}&error_a=1");
			if($kl_id > 0){
				$DB->query('update '.DB_PREFIX."kl_auto_internal_links set `word`='{$kl_word}', `url`='{$kl_url}', `target`={$kl_target}, `nofollow`={$kl_nofollow}, `title`={$kl_title}, `title_text`='{$kl_title_text}', `class`={$kl_class}, `weight`={$kl_weight} where id={$kl_id}");
				kl_auto_internal_links_update_custom();
				emDirect("./plugin.php?plugin=kl_auto_internal_links&act=custom{$keyword_url}&page={$page}&active_edit=1");
			}else{
				$DB->query('insert into '.DB_PREFIX."kl_auto_internal_links(`word`, `url`, `target`, `nofollow`, `title`, `title_text`, `class`, `weight`) values('{$kl_word}', '{$kl_url}', {$kl_target}, {$kl_nofollow}, {$kl_title}, '{$kl_title_text}', {$kl_class}, {$kl_weight})");
				kl_auto_internal_links_update_custom();
				emDirect("./plugin.php?plugin=kl_auto_internal_links&act=custom&active_add=1");
			}
		}elseif(isset($_GET['do']) && trim($_GET['do']) == 'edit'){
			$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
			if($id > 0){
				$query = $DB->query('select * from '.DB_PREFIX."kl_auto_internal_links where id={$id}");
				if($DB->num_rows($query) > 0) $the_word = $DB->fetch_array($query);
			}
		}elseif(isset($_GET['do']) && trim($_GET['do']) == 'del'){
			$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
			if($id > 0){
				$query = $DB->query('delete from '.DB_PREFIX."kl_auto_internal_links where id={$id}");
				if($DB->affected_rows() > 0){
					kl_auto_internal_links_update_custom();
					emDirect("./plugin.php?plugin=kl_auto_internal_links&act=custom{$keyword_url}&page={$page}&active_del=1");
				}
			}
		}
		$condition = empty($keyword) ? '' : " where word like '%{$keyword}%'";
		$result = $DB->once_fetch_array('select count(1) num from '.DB_PREFIX.'kl_auto_internal_links'.$condition);
		$page_all_no = $result['num'];
		$page_num = 10;
		$pageurl =  pagination($page_all_no, $page_num, $page, 'plugin.php?plugin=kl_auto_internal_links&act=custom'.$keyword_url.'&page=');
		$start_num = !empty($page) ? ($page - 1) * $page_num : 0;
		$query = $DB->query('select * from '.DB_PREFIX."kl_auto_internal_links{$condition} order by id desc limit {$start_num}, {$page_num}");
		$words = array();
		while($row = $DB->fetch_array($query)) array_push($words, $row);
		$class_option_arr = array('kl_auto_internal_links_custom_0', 'kl_auto_internal_links_custom_1');
		$class_option_str = '';
		foreach($class_option_arr as $value=>$class){
			$selected = isset($the_word) && $value == $the_word['class'] ? ' selected' : '';
			$class_option_str .= "<option value=\"{$value}\"{$selected}>{$class}</option>";
		}
?>
<div class="containertitle2">
<a class="navi1" href="?plugin=kl_auto_internal_links">基本设置</a>
<a class="navi3" href="?plugin=kl_auto_internal_links&act=custom">自定义关键词</a>
<a class="navi4" href="?plugin=kl_auto_internal_links&act=do">手动操作</a>
<?php if(isset($_GET['active_del'])):?><span class="actived">删除成功</span><?php endif;?>
<?php if(isset($_GET['active_edit'])):?><span class="actived">修改成功</span><?php endif;?>
<?php if(isset($_GET['active_add'])):?><span class="actived">添加成功</span><?php endif;?>
<?php if(isset($_GET['error_a'])):?><span class="error">关键词和链接地址不能为空</span><?php endif;?>
<span style="float:right;margin-top:-10px;"><form action="./plugin.php?plugin=kl_auto_internal_links" method="GET"><input type="hidden" name="plugin" value="kl_auto_internal_links" /><input type="hidden" name="act" value="custom" /><input id="input_s" name="keyword" /></form></span>
</div>
<table width="100%" id="kl_auto_internal_links_list" class="item_list">
	<thead>
		<tr>
			<th width="50"><b>序号</b></th>
			<th width="80"><b>关键词</b></th>
			<th width="200"><b>url</b></th>
			<th width="60" class="tdcenter"><b>新窗口</b></th>
			<th width="60" class="tdcenter"><b>nofollow</b></th>
			<th width="60" class="tdcenter"><b>显示title</b></th>
			<th width="200" class="tdcenter"><b>title模板</b></th>
			<th width="80" class="tdcenter"><b>样式(简写)</b></th>
			<th width="50" class="tdcenter"><b>权重</b></th>
			<th width="100" class="tdcenter">操作</th>
		</tr>
	</thead>
	<tbody>
	<?php 
	if($words):
	foreach($words as $key=>$value):
	?>  
		<tr>
			<td><?php echo $value['id']; ?></td>
			<td><a href="plugin.php?plugin=kl_auto_internal_links&act=custom<?php echo $keyword_url; ?>&page=<?php echo $page; ?>&do=edit&id=<?php echo $value['id']; ?>" title="修改关键词"><?php echo $value['word']; ?></a></td>
			<td><?php echo $value['url']; ?></td>
			<td class="tdcenter"><?php echo $value['target'] ? '是' : '否'; ?></td>
			<td class="tdcenter"><?php echo $value['nofollow'] ? '是' : '否'; ?></td>
			<td class="tdcenter"><?php echo $value['title'] ? '是' : '否'; ?></td>
			<td class="tdcenter"><?php echo $value['title_text']; ?></td>
			<td class="tdcenter"><?php echo $value['class']; ?></td>
			<td class="tdcenter"><?php echo $value['weight']; ?></td>
			<td class="tdcenter">
				<a href="plugin.php?plugin=kl_auto_internal_links&act=custom<?php echo $keyword_url; ?>&page=<?php echo $page?>&do=edit&id=<?php echo $value['id']; ?>">编辑</a>
				<a href="plugin.php?plugin=kl_auto_internal_links&act=custom<?php echo $keyword_url; ?>&page=<?php echo $page; ?>&do=del&id=<?php echo $value['id']; ?>" onclick="javascript:if(!confirm('确定要删除此关键词？')){return false;}" class="care">删除</a>
			</td>
		</tr>
	<?php endforeach;else:?>
		<tr><td class="tdcenter" colspan="6">还没有添加关键词</td></tr>
	<?php endif;?>
	</tbody>
</table>
<div class="page"><?php echo $pageurl; ?> (共有<?php echo $page_all_no; ?>个关键词)</div>
<form action="?plugin=kl_auto_internal_links&act=custom<?php echo $keyword_url; ?>&page=<?php echo $page; ?>&do=add" method="post" name="link" id="link">
<div style="margin:30px 0px 10px 0px;"><strong>添加 / 编辑关键词</strong> <span style="color:#999999;">(为了程序更有效率的工作，请把关键词控制在5000个以内..)</span></div>
<div id="word_new">
	<table width="200" border="0" cellspacing="1" cellpadding="0" class="table_b">
		<tr>
			<td width="100">关键词：</td>
			<td><input maxlength="30" style="width:240px;" name="kl_word" value="<?php if(isset($the_word['word'])) echo $the_word['word'];?>" /></td>
		</tr>
		<tr>
			<td>链接地址：</td>
			<td><input maxlength="255" style="width:400px;" name="kl_url" value="<?php if(isset($the_word['url'])) echo $the_word['url'];?>" /></td>
		</tr>
		<tr>
			<td>title模板：</td>
			<td><input maxlength="255" style="width:400px;" name="kl_title_text" value="<?php echo empty($the_word['title_text']) ? '查看和 {custom} 相关的文章' : $the_word['title_text'];?>" /> * 模板中的{custom}最终会替换成关键词</td>
		</tr>
		<tr>
			<td>选择样式：</td>
			<td><select name="kl_class"><?php echo $class_option_str; ?></select></td>
		</tr>
		<tr>
			<td>其它：</td>
			<td>
				<label><input name="kl_target" type="checkbox" value="1"<?php if(isset($the_word['target']) && $the_word['target']) echo ' checked';?> />新窗口打开</label>
				<label><input name="kl_nofollow" type="checkbox" value="1"<?php if(isset($the_word['nofollow']) && $the_word['nofollow']) echo ' checked';?> />添加nofollow</label>
				<label><input name="kl_title" type="checkbox" value="1"<?php if(isset($the_word['title']) && $the_word['title']) echo ' checked';?> />显示title</label>
				<span style="margin-left:10px;">权重：<input id="kl_weight" maxlength="5" name="kl_weight" type="text" style="width:40px;" value="<?php echo isset($the_word['weight']) ? $the_word['weight'] : 10;?>" /></span>
			</td>
		</tr>
		<tr>
			<td></td>
			<td><input name="kl_id" type="hidden" value="<?php if(isset($the_word['id'])) echo $the_word['id'];?>" /><input type="submit" name="" value="保存关键词"  /></td>
		</tr>
	</table>
</div>
</form>
<script type="text/javascript">
$(document).ready(function(){
	$("#kl_auto_internal_links_list tbody tr:odd").addClass("tralt_b");
	$("#kl_auto_internal_links_list tbody tr").mouseover(function(){$(this).addClass("trover")}).mouseout(function(){$(this).removeClass("trover")})
});
</script>
<?php
		exit;
	}
	$priority_option_arr = array('分类 标签 自定义关键词', '分类 自定义关键词 标签', '标签 分类 自定义关键词', '标签 自定义关键词 分类', '自定义关键词 分类 标签', '自定义关键词 标签 分类');
	$priority_option_str = '';
	foreach($priority_option_arr as $value=>$priority){
		$selected = $value == $kl_auto_internal_links_info['priority'] ? ' selected' : '';
		$priority_option_str .= "<option value=\"{$value}\"{$selected}>{$priority}</option>";
	}

	$how_option_arr = array('重新生成内链', '生成过就不要再生成内链', '清除生成过的内链');
	$how_option_str = '';
	foreach($how_option_arr as $value=>$how){
		$selected = $value == $kl_auto_internal_links_info['how'] ? ' selected' : '';
		$how_option_str .= "<option value=\"{$value}\"{$selected}>{$how}</option>";
	}
?>
<div class="containertitle2">
<a class="navi3" href="?plugin=kl_auto_internal_links">基本设置</a>
<a class="navi4" href="?plugin=kl_auto_internal_links&act=custom">自定义关键词</a>
<a class="navi4" href="?plugin=kl_auto_internal_links&act=do">手动操作</a>
<?php if(isset($_GET['setting'])):?><span class="actived">插件设置完成</span><?php endif;?>
</div>
<div style="height:400px;">
	<form id="form1" name="form1" method="post" action="plugin.php?plugin=kl_auto_internal_links&action=setting">
		<table width="500" border="0" cellspacing="1" cellpadding="0" class="table_b">
			<tr>
				<td width="135" height="30" rowspan="3">词库：</td>
				<td width="380">
					<span style="color:#2A9DDB;font-weight:bold;">词库一：</span><label><input name="kl_sort" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_sort']) echo 'checked'; ?>/>分类</label>
					<label><input name="kl_sort_target" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_sort_target']) echo 'checked'; ?>/>新窗口打开</label>
					<label><input name="kl_sort_nofollow" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_sort_nofollow']) echo 'checked'; ?>/>nofollow</label>
					<label><input name="kl_sort_title" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_sort_title']) echo 'checked'; ?>/>显示title</label>
					<br /><span>title模板：<input name="kl_sort_title_text" type="text" style="width:210px;" value="<?php echo $kl_auto_internal_links_info['kl_sort_title_text']; ?>" /></span>
					<span style="margin-left:10px;">权重：<input name="kl_sort_weight" maxlength="5" type="text" id="kl_sort_weight" style="width:40px;" value="<?php echo $kl_auto_internal_links_info['kl_sort_weight'];?>" /></span>
				</td>
				<td>* 分类<br />title模板中的{sort}最终会替换成分类关键词</td>
			</tr>
			<tr>
				<td>
					<span style="color:#2A9DDB;font-weight:bold;">词库二：</span><label><input name="kl_tag" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_tag']) echo 'checked'; ?>/>标签</label>
					<label><input name="kl_tag_target" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_tag_target']) echo 'checked'; ?>/>新窗口打开</label>
					<label><input name="kl_tag_nofollow" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_tag_nofollow']) echo 'checked'; ?>/>nofollow</label>
					<label><input name="kl_tag_title" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_tag_title']) echo 'checked'; ?>/>显示title</label>
					<br /><span>title模板：<input name="kl_tag_title_text" type="text" style="width:210px;" value="<?php echo $kl_auto_internal_links_info['kl_tag_title_text']; ?>" /></span>
					<span style="margin-left:10px;">权重：<input name="kl_tag_weight" maxlength="5" type="text" id="kl_tag_weight" style="width:40px;" value="<?php echo $kl_auto_internal_links_info['kl_tag_weight'];?>" /></span>
				</td>
				<td>* 标签<br />title模板中的{sort}最终会替换成标签关键词</td>
			</tr>
			<tr>
				<td><span style="color:#2A9DDB;font-weight:bold;">词库三：</span><label><input name="kl_custom" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['kl_custom']) echo 'checked'; ?>/>自定义关键词</label></td>
				<td>* 自定义关键词</td>
			</tr>
			<tr>
				<td height="30"><span style="width:200px;">词库优先级：</span></td>
				<td><select name="priority"><?php echo $priority_option_str; ?></select></td>
				<td>* 当一个词在多个词库中出现时，优先取它在哪个词库中的链接</td>
			</tr>
			<tr>
				<td height="30">单个内链出现频率限制：</td>
				<td><input name="each_count" type="text" id="each_count" style="width:140px;" value="<?php echo $kl_auto_internal_links_info['each_count'];?>" /></td>
				<td>* 同一篇文章中生成的单个内链次数限制（0为不限制）</td>
			</tr>
			<tr>
				<td height="30">内链总数限制：</td>
				<td><input name="all_count" type="text" id="all_count" style="width:140px;" value="<?php echo $kl_auto_internal_links_info['all_count'];?>" /></td>
				<td>* 同一篇文章中生成的内链总数限制（0为不限制）</td>
			</tr>
			<tr>
				<td height="30"><span style="color:red;">插件的工作方式：</span></td>
				<td><select name="how"><?php echo $how_option_str; ?></select><label><input name="onsave" type="checkbox" value="1" <?php if($kl_auto_internal_links_info['onsave']) echo 'checked'; ?>/>保存文章时自动执行</label></td>
				<td>* 插件的工作方式</td>
			</tr>
			<tr>
				<td height="150">链接的样式：</td>
				<td><textarea name="css" rows="5" style="width:365px;height:140px;"><?php if($kl_auto_internal_links_info['css'] != '') echo base64_decode($kl_auto_internal_links_info['css']); ?></textarea></td>
				<td>* 链接的样式，作用于由本插件生成的链接。<br />可选的有效样式包括：<br />kl_auto_internal_links_sort<br />kl_auto_internal_links_tag<br />kl_auto_internal_links_custom_0<br />kl_auto_internal_links_custom_1</td>
			</tr>
			<tr>
				<td height="37"></td>
				<td><input name="input" type="submit" value="保　存" /></td>
				<td></td>
			</tr>
		</table>
	</form>
</div>
<?php
}

function plugin_setting()
{
	$kl_auto_internal_links_info = unserialize(Option::get('kl_auto_internal_links_info'));
	$info = array('version'=>$kl_auto_internal_links_info['version']);
	$intval_argu_arr = array('kl_sort', 'kl_sort_target', 'kl_sort_nofollow', 'kl_sort_title', 'kl_sort_weight', 'kl_tag', 'kl_tag_target', 'kl_tag_nofollow', 'kl_tag_title', 'kl_tag_weight', 'kl_custom', 'priority', 'each_count', 'all_count', 'how', 'onsave');
	foreach($intval_argu_arr as $iaav) $info[$iaav] = isset($_POST[$iaav]) ? intval($_POST[$iaav]) : 0;
	if($info['kl_sort_weight'] > 99999) $info['kl_sort_weight'] = 99999;
	if($info['kl_tag_weight'] > 99999) $info['kl_tag_weight'] = 99999;
	$info['kl_sort_title_text'] = isset($_POST['kl_sort_title_text']) ? addslashes(trim($_POST['kl_sort_title_text'])) : '';
	$info['kl_tag_title_text'] = isset($_POST['kl_tag_title_text']) ? addslashes(trim($_POST['kl_tag_title_text'])) : '';
	$info['css'] = isset($_POST['css']) ? base64_encode($_POST['css']) : '';
	$info = serialize($info);
	Option::updateOption('kl_auto_internal_links_info', $info);
	global $CACHE;
	$CACHE->updateCache('options');
}