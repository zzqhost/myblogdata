<?php
/**
 * kl_auto_internal_links_callback.php
 * design by KLLER
 */
function callback_init()
{
	global $CACHE;
	$CACHE->updateCache('options');
	$kl_auto_internal_links_info = Option::get('kl_auto_internal_links_info');
	$DB = MySql::getInstance();
	if(is_null($kl_auto_internal_links_info)){
		$css = '<style type="text/css">
.kl_auto_internal_links_sort a:link{color:red;}
.kl_auto_internal_links_sort a:visited{color:red;}
.kl_auto_internal_links_tag a:link{color:green;}
.kl_auto_internal_links_tag a:visited{color:green;}
.kl_auto_internal_links_custom_0 a:link{color:blue;}
.kl_auto_internal_links_custom_0 a:visited{color:blue;}
.kl_auto_internal_links_custom_1 a:link{color:blue;}
.kl_auto_internal_links_custom_1 a:visited{color:blue;}
</style>';
		$info = array('version'=>'1.0', 'kl_sort'=>1, 'kl_sort_target'=>1, 'kl_sort_nofollow'=>0, 'kl_sort_title'=>1, 'kl_sort_title_text'=>'查看分类为 {sort} 的文章', 'kl_sort_weight'=>10, 'kl_tag'=>1, 'kl_tag_target'=>1, 'kl_tag_nofollow'=>0, 'kl_tag_title'=>1, 'kl_tag_title_text'=>'查看标签为 {tag} 的文章', 'kl_tag_weight'=>10, 'kl_custom'=>0, 'priority'=>4, 'each_count'=>3, 'all_count'=>6, 'how'=>0, 'onsave'=>1, 'css'=>base64_encode($css));
		$info = serialize($info);
		$DB->query("INSERT INTO ".DB_PREFIX."options(option_name, option_value) VALUES('kl_auto_internal_links_info', '{$info}')");
	}
	$CACHE->updateCache('options');

	$dbcharset = 'utf8';
	$type = 'MYISAM';
	$add = $DB->getMysqlVersion() > '4.1' ? "ENGINE=".$type." DEFAULT CHARSET=".$dbcharset.";":"TYPE=".$type.";";
	$sql = "
	CREATE TABLE IF NOT EXISTS `".DB_PREFIX."kl_auto_internal_links` (
		`id` int(10) unsigned NOT NULL AUTO_INCREMENT,
		`word` varchar(255) NOT NULL,
		`url` varchar(255) NOT NULL DEFAULT '',
		`target` tinyint(1) unsigned NOT NULL DEFAULT '0',
		`nofollow` tinyint(1) unsigned NOT NULL DEFAULT '0',
		`title` tinyint(1) unsigned NOT NULL DEFAULT '0',
		`title_text` varchar(255) NOT NULL DEFAULT '',
		`class` tinyint(1) unsigned NOT NULL DEFAULT '0',
		`weight` int(10) unsigned NOT NULL DEFAULT '0',
		PRIMARY KEY (`id`)
	)".$add;	
	$DB->query($sql);
}

function callback_rm(){}