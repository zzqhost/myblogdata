<?php
define('THEMESEDITOR_CTHEME','TangStyle');
define('THEMESEDITOR_CFILE','module.php');
define('CODEMIRROR_THEME','eclipse');
define('THEMESEDITOR_EDITOR_THEMES',"ambiance,blackboard,cobalt,eclipse,elegant,erlang-dark,lesser-dark,monokai,neat,night,rubyblue,twilight,vibrant-ink,xq-dark");
