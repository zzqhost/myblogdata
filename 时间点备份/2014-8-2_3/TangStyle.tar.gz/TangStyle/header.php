<?php
/*
Template Name:TangStyle
Description:响应式Web设计，自适应电脑、平板电脑、移动设备。
Version:2.0
Author:留日记
Author Url:http://www.liudiary.com
ForEmlog:5.1.2
*/
if(!defined('EMLOG_ROOT')) {exit('error!');}
require_once View::getView('module');
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title><?php echo $site_title; ?></title>
<meta name="keywords" content="<?php echo $site_key; ?>" />
<meta name="description" content="<?php echo $site_description; ?>" />
<meta name="generator" content="emlog" />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
<link rel="alternate" type="application/rss+xml" title="RSS"  href="<?php echo BLOG_URL; ?>rss.php" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<link href="<?php echo TEMPLATE_URL; ?>style.css" rel="stylesheet" type="text/css" />
<script src="<?php echo TEMPLATE_URL; ?>jquery.min.js"></script>
<script src="<?php echo TEMPLATE_URL; ?>theme.js"></script>
<script src="<?php echo BLOG_URL; ?>include/lib/js/common_tpl.js"></script>
<?php doAction('index_head'); ?>
</head>

<body>
<div id="wrap">
	
<div id="header">
    <div class="logo"><a href="<?php echo BLOG_URL; ?>"><?php echo $blogname; ?></a><p><?php echo $bloginfo; ?></p></div>
    <div id="navigation">
	
	<?php blog_navi();?>
	
    <ul class="my">
        <li><a href="#"><i class="iconfont">&#260;</i>关注我</a>
            <ul>
                <li><a href="http://blog.csdn.net/zzqhost" rel="external nofollow" target="_blank"><i class="iconfont">&#468;</i>CSDN博客</a></li>
                <li><a href="http://zzqhost.blog.163.com/" rel="external nofollow" target="_blank"><i class="iconfont">&#469;</i>163博客</a></li>
				<li><a href="http://zzqhost.github.io/hostwiki/" rel="external nofollow" target="_blank"><i class="iconfont">&#483;</i>Github博客</a></li>
            </ul>
        </li>
    </ul>
    </div>
</div>
<div id="content">